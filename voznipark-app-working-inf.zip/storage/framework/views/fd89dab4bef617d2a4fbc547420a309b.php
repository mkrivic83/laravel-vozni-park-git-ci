<!doctype html>
<html lang="hr">
<head>
    <meta charset="utf-8">
    <title>Uredi vozilo</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-100">
<?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="max-w-xl mx-auto py-10">
    <h1 class="text-2xl font-bold mb-6">Uredi vozilo</h1>

    <div class="bg-white shadow rounded p-6">
        <form method="POST" action="<?php echo e(route('vozila.update', $vozilo)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block font-medium">Naziv</label>
                <input type="text" name="naziv"
                       class="mt-1 w-full border rounded px-3 py-2"
                       value="<?php echo e(old('naziv', $vozilo->naziv)); ?>">
                <?php $__errorArgs = ['naziv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block font-medium">Tip</label>
                <input type="text" name="tip"
                       class="mt-1 w-full border rounded px-3 py-2"
                       value="<?php echo e(old('tip', $vozilo->tip)); ?>">
                <?php $__errorArgs = ['tip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block font-medium">Motor</label>
                <input type="text" name="motor"
                       class="mt-1 w-full border rounded px-3 py-2"
                       value="<?php echo e(old('motor', $vozilo->motor)); ?>">
                <?php $__errorArgs = ['motor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block font-medium">Registracija</label>
                <input type="text" name="registracija"
                       class="mt-1 w-full border rounded px-3 py-2"
                       value="<?php echo e(old('registracija', $vozilo->registracija)); ?>">
                <?php $__errorArgs = ['registracija'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block font-medium">Istek registracije</label>
                <input type="date" name="istek_registracije"
                       class="mt-1 w-full border rounded px-3 py-2"
                       value="<?php echo e(old('istek_registracije', $vozilo->istek_registracije->format('Y-m-d'))); ?>">
                <?php $__errorArgs = ['istek_registracije'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-6">
                <label class="block font-medium">Namjena</label>
                <select name="namjenaid"
                        class="mt-1 w-full border rounded px-3 py-2">
                    <?php $__currentLoopData = $namjene; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($n->id); ?>"
                            <?php if(old('namjenaid', $vozilo->namjenaid) == $n->id): echo 'selected'; endif; ?>>
                            <?php echo e($n->naziv); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['namjenaid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex justify-end gap-3">
                <a href="<?php echo e(route('vozila.index')); ?>"
                   class="px-4 py-2 border rounded hover:bg-gray-100">
                    Nazad
                </a>

                <button class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    Spremi izmjene
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html><?php /**PATH C:\xampp\www\personal\LaravelOOP\voznipark-app\resources\views/vozila/edit.blade.php ENDPATH**/ ?>

# See https://laravel.com/docs/9.x/octane#serving-your-application-via-nginx
map $http_upgrade $connection_upgrade {
    default upgrade;
    ''      close;
}<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/nginx/conf_d/websockets_conf.blade.php ENDPATH**/ ?>
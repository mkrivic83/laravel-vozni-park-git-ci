php8.2-bcmath
php8.2-cli
php8.2-common
php8.2-curl
php8.2-gd
php8.2-intl
php8.2-mbstring
php8.2-mysql
php8.2-pgsql
php8.2-redis
php8.2-soap
php8.2-sqlite3
php8.2-xml
php8.2-zip
php8.2-swoole
php8.2-fpm<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/php/packages/8_2_txt.blade.php ENDPATH**/ ?>
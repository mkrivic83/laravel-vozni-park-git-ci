php8.4-bcmath
php8.4-cli
php8.4-common
php8.4-curl
php8.4-gd
php8.4-intl
php8.4-mbstring
php8.4-mysql
php8.4-pgsql
php8.4-redis
php8.4-soap
php8.4-sqlite3
php8.4-xml
php8.4-zip
php8.4-fpm<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/php/packages/8_4_txt.blade.php ENDPATH**/ ?>
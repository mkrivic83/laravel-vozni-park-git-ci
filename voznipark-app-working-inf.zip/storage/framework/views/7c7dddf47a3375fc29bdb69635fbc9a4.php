php7.4-bcmath
php7.4-cli
php7.4-common
php7.4-curl
php7.4-gd
php7.4-intl
php7.4-json
php7.4-mbstring
php7.4-mysql
php7.4-pgsql
php7.4-redis
php7.4-soap
php7.4-sqlite3
php7.4-xml
php7.4-zip
php7.4-swoole
php7.4-fpm<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/php/packages/7_4_txt.blade.php ENDPATH**/ ?>
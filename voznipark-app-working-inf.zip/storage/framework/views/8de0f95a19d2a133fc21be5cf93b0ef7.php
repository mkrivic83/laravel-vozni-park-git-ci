
#!/usr/bin/env bash

sleep 0.25 && exec nginx
<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/start-nginx_sh.blade.php ENDPATH**/ ?>
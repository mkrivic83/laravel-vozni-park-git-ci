php8.0-bcmath
php8.0-cli
php8.0-common
php8.0-curl
php8.0-gd
php8.0-intl
php8.0-mbstring
php8.0-mysql
php8.0-pgsql
php8.0-redis
php8.0-soap
php8.0-sqlite3
php8.0-xml
php8.0-zip
php8.0-swoole
php8.0-fpm<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/php/packages/8_0_txt.blade.php ENDPATH**/ ?>